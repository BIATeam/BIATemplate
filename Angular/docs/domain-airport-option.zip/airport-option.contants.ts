// IMPORTANT: this key should be unique in all the application. Use the path of the feature.
export const storeKey: string = 'domain-airport-options';