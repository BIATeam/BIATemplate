export interface AircraftMaintenanceCompany {
  id: number;
  title: string;
}