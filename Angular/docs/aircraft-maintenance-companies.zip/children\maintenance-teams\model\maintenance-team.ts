export interface MaintenanceTeam {
  id: number;
  title: string;
}