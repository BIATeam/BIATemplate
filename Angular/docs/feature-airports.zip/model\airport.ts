export interface Airport {
  id: number;
  name: string;
  city: string;
}
